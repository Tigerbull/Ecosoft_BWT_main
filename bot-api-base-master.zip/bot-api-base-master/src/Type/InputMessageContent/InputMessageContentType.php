<?php

declare(strict_types=1);

namespace TgBotApi\BotApiBase\Type\InputMessageContent;

/**
 * Class InputMessageContentType.
 *
 * @see https://core.telegram.org/bots/api#inputmessagecontent
 */
abstract class InputMessageContentType
{
}
