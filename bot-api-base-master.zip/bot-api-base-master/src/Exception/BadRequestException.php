<?php

declare(strict_types=1);

namespace TgBotApi\BotApiBase\Exception;

/**
 * Class BadRequestException.
 */
class BadRequestException extends \Exception
{
}
