<?php

declare(strict_types=1);

namespace TgBotApi\BotApiBase\Exception;

/**
 * Class BadArgumentException.
 */
class BadArgumentException extends \Exception
{
}
