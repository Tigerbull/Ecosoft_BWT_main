<?php

declare(strict_types=1);

namespace TgBotApi\BotApiBase\Exception;

/**
 * Class ResponseException.
 */
class ResponseException extends \Exception
{
}
