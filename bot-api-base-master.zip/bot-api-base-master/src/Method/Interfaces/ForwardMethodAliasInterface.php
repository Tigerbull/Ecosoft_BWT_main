<?php

declare(strict_types=1);

namespace TgBotApi\BotApiBase\Method\Interfaces;

/**
 * Class ForwardMethodAliasInterface.
 */
interface ForwardMethodAliasInterface extends MethodInterface
{
}
