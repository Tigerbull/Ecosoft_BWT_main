<?php

declare(strict_types=1);

namespace TgBotApi\BotApiBase\Method\Interfaces;

/**
 * Interface CreateMethodAliasInterface.
 */
interface CreateMethodAliasInterface extends MethodInterface
{
}
