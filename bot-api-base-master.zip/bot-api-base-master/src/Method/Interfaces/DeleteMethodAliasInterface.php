<?php

declare(strict_types=1);

namespace TgBotApi\BotApiBase\Method\Interfaces;

/**
 * Class DeleteMethodAliasInterface.
 */
interface DeleteMethodAliasInterface extends MethodInterface
{
}
