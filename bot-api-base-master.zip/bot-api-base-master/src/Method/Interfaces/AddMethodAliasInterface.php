<?php

declare(strict_types=1);

namespace TgBotApi\BotApiBase\Method\Interfaces;

/**
 * Interface AddMethodAliasInterface.
 */
interface AddMethodAliasInterface extends MethodInterface
{
}
