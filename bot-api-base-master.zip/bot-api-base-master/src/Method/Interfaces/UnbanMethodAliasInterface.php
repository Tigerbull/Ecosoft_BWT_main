<?php

declare(strict_types=1);

namespace TgBotApi\BotApiBase\Method\Interfaces;

/**
 * Interface UnbanMethodAliasInterface.
 */
interface UnbanMethodAliasInterface extends MethodInterface
{
}
