<?php

declare(strict_types=1);

namespace TgBotApi\BotApiBase\Method\Interfaces;

/**
 * Interface SetMethodAliasInterface.
 */
interface SetMethodAliasInterface extends MethodInterface
{
}
