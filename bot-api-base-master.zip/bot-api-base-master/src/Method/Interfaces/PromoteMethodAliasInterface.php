<?php

declare(strict_types=1);

namespace TgBotApi\BotApiBase\Method\Interfaces;

/**
 * Class PromoteMethodAliasInterface.
 */
interface PromoteMethodAliasInterface extends MethodInterface
{
}
