<?php

declare(strict_types=1);

namespace TgBotApi\BotApiBase\Method\Interfaces;

/**
 * Interface PinMethodAliasInterface.
 */
interface PinMethodAliasInterface extends MethodInterface
{
}
