<?php

declare(strict_types=1);

namespace TgBotApi\BotApiBase\Method\Traits;

trait GooglePlaceFieldsTrait
{
    use \TgBotApi\BotApiBase\Type\Traits\GooglePlaceFieldsTrait;
}
