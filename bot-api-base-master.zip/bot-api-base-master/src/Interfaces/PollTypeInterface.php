<?php

declare(strict_types=1);

namespace TgBotApi\BotApiBase\Interfaces;

interface PollTypeInterface
{
    public const TYPE_REGULAR = 'regular';
    public const TYPE_QUIZ = 'quiz';
}
